
export interface FormState {
  jobTitle: string;
  companyName: string;
  jobDescription: string;
  userResume: string;
}
