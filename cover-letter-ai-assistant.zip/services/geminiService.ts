
import { GoogleGenAI } from "@google/genai";
import { FormState } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateCoverLetter(formData: FormState): Promise<string> {
    const { jobTitle, companyName, jobDescription, userResume } = formData;

    if (!jobTitle || !companyName || !jobDescription || !userResume) {
        throw new Error("All fields are required to generate a cover letter.");
    }
    
    const prompt = `
    You are an expert career coach specializing in writing compelling, professional, and tailored cover letters. Your task is to generate a cover letter based on the provided details.

    The tone of the cover letter should be enthusiastic, professional, and confident, avoiding generic clichés. It must directly address how the candidate's skills and experiences, as detailed in their resume, are a strong match for the requirements outlined in the job description. Structure the letter with a clear introduction, body paragraphs that connect specific resume points to job requirements, and a strong concluding paragraph with a call to action.

    **Job Title:**
    ${jobTitle}

    **Company Name:**
    ${companyName}

    **Job Description:**
    ---
    ${jobDescription}
    ---

    **Candidate's Resume/CV:**
    ---
    ${userResume}
    ---

    Generate the cover letter now. Ensure the output is only the cover letter text itself, without any additional commentary or explanation.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating cover letter:", error);
        throw new Error("Failed to generate cover letter. Please check the console for more details.");
    }
}
