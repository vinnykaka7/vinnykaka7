
import React, { useState, useCallback } from 'react';
import { InputForm } from './components/InputForm';
import { CoverLetterDisplay } from './components/CoverLetterDisplay';
import { generateCoverLetter } from './services/geminiService';
import { FormState } from './types';

const App: React.FC = () => {
  const [formState, setFormState] = useState<FormState>({
    jobTitle: '',
    companyName: '',
    jobDescription: '',
    userResume: '',
  });

  const [generatedCoverLetter, setGeneratedCoverLetter] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFormChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState(prevState => ({
      ...prevState,
      [name]: value,
    }));
  }, []);

  const handleSubmit = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setGeneratedCoverLetter('');
    try {
      const letter = await generateCoverLetter(formState);
      setGeneratedCoverLetter(letter);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [formState]);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold leading-tight text-gray-900 text-center">
            Cover Letter AI Assistant
          </h1>
          <p className="text-center text-gray-500 mt-1">
            Craft the perfect cover letter in seconds.
          </p>
        </div>
      </header>
      <main className="py-10">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 px-4 sm:px-6 lg:px-8">
          <InputForm
            formState={formState}
            isLoading={isLoading}
            onFormChange={handleFormChange}
            onSubmit={handleSubmit}
          />
          <CoverLetterDisplay
            coverLetter={generatedCoverLetter}
            isLoading={isLoading}
            error={error}
          />
        </div>
      </main>
    </div>
  );
};

export default App;
