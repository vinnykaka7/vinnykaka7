
import React from 'react';
import { FormState } from '../types';

interface InputFormProps {
  formState: FormState;
  isLoading: boolean;
  onFormChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  onSubmit: () => void;
}

const Label: React.FC<{ htmlFor: string; children: React.ReactNode }> = ({ htmlFor, children }) => (
  <label htmlFor={htmlFor} className="block text-sm font-medium text-gray-700 mb-1">
    {children}
  </label>
);

const Input: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => (
  <input
    {...props}
    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
  />
);

const Textarea: React.FC<React.TextareaHTMLAttributes<HTMLTextAreaElement>> = (props) => (
  <textarea
    {...props}
    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
  />
);


export const InputForm: React.FC<InputFormProps> = ({ formState, isLoading, onFormChange, onSubmit }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4 text-gray-900">Your Details</h2>
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="jobTitle">Job Title</Label>
            <Input
              type="text"
              name="jobTitle"
              id="jobTitle"
              value={formState.jobTitle}
              onChange={onFormChange}
              placeholder="e.g., Senior Frontend Engineer"
              disabled={isLoading}
            />
          </div>
          <div>
            <Label htmlFor="companyName">Company Name</Label>
            <Input
              type="text"
              name="companyName"
              id="companyName"
              value={formState.companyName}
              onChange={onFormChange}
              placeholder="e.g., Acme Inc."
              disabled={isLoading}
            />
          </div>
        </div>
        <div>
          <Label htmlFor="jobDescription">Job Description</Label>
          <Textarea
            name="jobDescription"
            id="jobDescription"
            rows={8}
            value={formState.jobDescription}
            onChange={onFormChange}
            placeholder="Paste the job description here..."
            disabled={isLoading}
          />
        </div>
        <div>
          <Label htmlFor="userResume">Your Resume/CV</Label>
          <Textarea
            name="userResume"
            id="userResume"
            rows={10}
            value={formState.userResume}
            onChange={onFormChange}
            placeholder="Paste your resume or relevant experience here..."
            disabled={isLoading}
          />
        </div>
        <div>
          <button
            onClick={onSubmit}
            disabled={isLoading}
            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-300 disabled:cursor-not-allowed transition-colors"
          >
            {isLoading ? (
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : null}
            {isLoading ? 'Generating...' : 'Generate Cover Letter'}
          </button>
        </div>
      </div>
    </div>
  );
};
