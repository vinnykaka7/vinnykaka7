
import React, { useState, useEffect } from 'react';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { CheckIcon } from './icons/CheckIcon';

interface CoverLetterDisplayProps {
  coverLetter: string;
  isLoading: boolean;
  error: string | null;
}

const LoadingSkeleton: React.FC = () => (
  <div className="space-y-4 animate-pulse">
    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
    <div className="h-4 bg-gray-200 rounded w-full"></div>
    <div className="h-4 bg-gray-200 rounded w-full"></div>
    <div className="h-4 bg-gray-200 rounded w-5/6"></div>
    <div className="h-4 bg-gray-200 rounded w-1/2 mt-6"></div>
    <div className="h-4 bg-gray-200 rounded w-full"></div>
    <div className="h-4 bg-gray-200 rounded w-full"></div>
    <div className="h-4 bg-gray-200 rounded w-full"></div>
    <div className="h-4 bg-gray-200 rounded w-4/6"></div>
  </div>
);

export const CoverLetterDisplay: React.FC<CoverLetterDisplayProps> = ({ coverLetter, isLoading, error }) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (coverLetter) {
      setCopied(false);
    }
  }, [coverLetter]);
  
  const handleCopy = () => {
    if (coverLetter) {
      navigator.clipboard.writeText(coverLetter);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const hasContent = !isLoading && !error && coverLetter;

  return (
    <div className="bg-white p-6 rounded-lg shadow-md relative h-full min-h-[500px] flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-900">Generated Cover Letter</h2>
        {hasContent && (
          <button
            onClick={handleCopy}
            className="flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
          >
            {copied ? (
              <CheckIcon className="h-5 w-5 mr-2" />
            ) : (
              <ClipboardIcon className="h-5 w-5 mr-2" />
            )}
            {copied ? 'Copied!' : 'Copy'}
          </button>
        )}
      </div>
      <div className="prose prose-sm max-w-none flex-grow overflow-y-auto pr-2">
        {isLoading && <LoadingSkeleton />}
        {error && (
          <div className="flex items-center justify-center h-full">
            <div className="text-center text-red-600">
              <h3 className="font-bold">An Error Occurred</h3>
              <p>{error}</p>
            </div>
          </div>
        )}
        {!isLoading && !error && !coverLetter && (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-500 text-center">
              Your generated cover letter will appear here.
              <br />
              Fill out the form to get started.
            </p>
          </div>
        )}
        {hasContent && <p className="whitespace-pre-wrap">{coverLetter}</p>}
      </div>
    </div>
  );
};
